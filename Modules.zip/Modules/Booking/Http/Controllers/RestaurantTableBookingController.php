<?php

namespace Modules\Booking\Http\Controllers;
use App\Http\Controllers\Controller;

class RestaurantTableBookingController extends Controller
{
    //get all booking Restaurant (admin or provider)
    //get all booking Restaurant by user (token or userId)
    //get all booking Restaurant (RestaurantId)
    //create Restaurant table booking (tableId ...)
    //check availablity table booking in Restaurant

}
