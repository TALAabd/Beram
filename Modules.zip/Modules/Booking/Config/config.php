<?php

return [
    'name' => 'Booking'
];
