<?php

return [
    'name' => 'Hotels'
];
