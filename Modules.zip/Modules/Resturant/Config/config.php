<?php

return [
    'name' => 'Resturant'
];
