<?php

// use App\Exceptions\PageExpiredException;
// use App\Exceptions\TooManyRequestsException;
use Illuminate\Foundation\Exceptions\Handler;

class Exception extends Handler
{
    // protected array $exceptions = [
    //     PageExpiredException::class,
    //     TooManyRequestsException::class,
    // ];

}
